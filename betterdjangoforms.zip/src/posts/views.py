from django.shortcuts import render

from .forms import PostForm #PostModelForm
from .models import Post, Author, Editor


def home(request):
	# form = PostModelForm(request.POST or None)
	if request.method == "POST":
		form = PostForm(request.POST)
		if form.is_valid():
			post = Post.objects.create(
					author = Author.objects.filter(name=form.cleaned_data.get("author")[0]).first(),
					editor = Editor.objects.filter(name=form.cleaned_data.get("editor")[0]).first(),
					publish_date = form.cleaned_data.get("publish_date")
				)

			post.title = form.cleaned_data.get("title")
			post.content = form.cleaned_data.get("content")
			post.draft = form.cleaned_data.get("draft")
			post.save()

	form = PostForm()
	context = {
		'form': form
	}
	return render(request, "posts/default_form.html", context)