from django import forms

from .models import Post, Author, Editor

class PostModelForm(forms.ModelForm):
	class Meta:
		model = Post
		fields = ['title','content','publish_date','author','editor','draft']


class PostForm(forms.Form):
	title = forms.CharField(widget=forms.TextInput(attrs={
			'placeholder': 'Give a title'
		}))
	content = forms.CharField(widget=forms.Textarea(attrs={
			'placeholder': 'Add some content',
			'rows': 3
		}))
	publish_date = forms.DateField(widget=forms.SelectDateWidget)
	author = forms.MultipleChoiceField(widget=forms.SelectMultiple, choices = [])
	editor = forms.MultipleChoiceField(widget=forms.SelectMultiple, choices = [])
	draft = forms.BooleanField(widget=forms.CheckboxInput)

	def __init__(self, *args, **kwargs):
		super(PostForm, self).__init__(*args, **kwargs)
		unique_authors = Author.objects.values_list('name', flat=True).distinct()
		unique_editors = Editor.objects.values_list('name', flat=True).distinct()
		self.fields['author'].choices = [(name, name) for name in unique_authors]
		self.fields['editor'].choices = [(name, name) for name in unique_editors]
